import { Component, ViewChild } from '@angular/core';
import { Observable } from 'rxjs/Rx';

@Component({
  moduleId: module.id,
  selector: 'basic-success-notify',
  templateUrl: 'basic-success-notify.component.html',
  styleUrls: ['basic-success-notify.component.css'],
})
export class BasicSuccessNotifyComponent {

  constructor() { }

}
